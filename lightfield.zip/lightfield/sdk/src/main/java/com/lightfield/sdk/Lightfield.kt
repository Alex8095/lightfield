package com.lightfield.sdk

class Lightfield {

    fun initialize(): Unit {}
}